for i in range(1, 21, 2):
    print(i, end=' ')
print()

for i in range(0, 101, 10):
    print(i, end=' ')
print()

for i in range(20, 0, -1):
    print(i, end=' ')
print()

star_numb = int(input("Enter number of stars: "))
for i in range(star_numb):
    print('*', end= ' ')
print()

for i in range(1, star_numb + 1):
    print('* ' * i)
    print()
