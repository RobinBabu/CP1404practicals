print('Hello World')
